#!/bin/bash

#Part1
echo "Part1"
aminoAcids=("Methionine" "Leucine" "Cysteine" "Alanine" "Valine" "Tyrosine" "Proline")
for acids in "${aminoAcids[@]}"; do
echo "$acids - Length: ${#acids}"
done
echo ""

#Part2
echo "Part2"
file="$1"
while file read -r line; do
echo "$line - Char count: ${#line}"
done < "$file"
echo ""

#Part3
echo "Part3"
count=0
quote="This script will run again"
until ! [ $count -lt 10 ]; do
echo "$quote"
quote="$quote and again"
((count++))
done
echo "Until it is done"
echo ""

#Part4
echo "Part4"
giveInfo(){
    echo "Name: Cade"
    echo "Username: $USER"
    echo "Date and Time: $(date)"
    echo "Current Directory: $(pwd)"
}
giveInfo
echo ""

#Part5
echo "Part5"
add() {
    num1=$1
    num2=$2
    sum=$((num1 + num2))
    echo "$num1 plus $num2 equals $sum"
    return 0
}
add 23 4
add 493 34
add 1 1