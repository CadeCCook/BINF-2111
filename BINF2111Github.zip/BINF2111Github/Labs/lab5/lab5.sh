# Part 1
# You tried to save MultiN.fastq from a text editor and it got corrupted (corrupted.fq).
# Give the bash command to find the corrupted sections by looking for the differences between the two files.

diff MultiN.fastq corrupted.fastq

# What were the differences/output?

# 93,94c93
# < @M00618:17:000000000-A31W7:1:1101:13859:2209 1:N:0:21
# < GGAGGCGAGAGCGGAGACGACGGTGATCTGGGAGATCGACGAGGGGCAGAAGCGCATCGAGGGCNNNNACGAGGCCGGTCGCCCCGACCCCGCCTACGCGGCCGCGCTCGGGCTCCGCCCCGCGCCGCTCGGCCGTCGCGCGCTCGCGTCGATCATCGAGCTCTCGCTCTACGCGCTGCTGCAGCTGCCGTACTGGCTCGTCGCCCTGCCCTCGCTCGTGCGGATCGCGACCGCACGCTCCGTCATGCGCG
# ---
# > TGATCTGGGAGATCGACGAGGGGCAGAAGCGCATCGAGGGCNNNNACGAGGCCGGTCGCCCCGACCCCGCCTACGCGGCCGCGCTCGGGCTCCGCCCCGCGCCGCTCGGCCGTCGCGCGCTCGCGTCGATCATCGAGCTCTCGCTCTACGCGCTGCTGCAGCTGCCGTACTGGCTCGTCGCCCTGCCCTCGCTCGTGCGGATCGCGACCGCACGCTCCGTCATGCGCG
# 1421,1424c1420
# < @M00618:17:000000000-A31W7:1:1101:15910:4449 1:N:0:21
# < CACGAGGCGGTGCGCGAGCGCCGGCACGGCGAGCGCCTTGACGTCGTCGGGGGTCACGTAGTCGCGGCCGTGGATCGCTGCCCACGCGCGCGCCGTCCGCACGAGCGCGAGCGCGCCGCGCACCGAGACGCCCAGGCGCACCTCGTCGGCCTCGCGCGTCGCGTCGACGAGCCGCGCGACGTAGTCGACGATCGACGCCTCGACGTGGACGCCGCGCACCTGGTCCGCGAGCGGGCCGGACGGCCATGTGC
# < +
# < AAAAAAAADEDDDDDDGGGGGGHHHHHHHHHHHHHHHHGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGAGGGGGGGECEEDGGDGGGGGGDA>GGEGDGGD<DGGGGGGGGDGGDAD>AGGGG<8?CC?8.4<>E.<C8>'.9CEGA84?88*''5'.'..'8:*****...5'4.'''''''''''''*****
# ---
# > AAADEDDDDDDGGGGGGHHHHHHHHHHHHHHHHGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGAGGGGGGGECEEDGGDGGGGGGDA>GGEGDGGD<DGGGGGGGGDGGDAD>AGGGG<8?CC?8.4<>E.<C8>'.9CEGA84?88*''5'.'..'8:*****...5'4.'''''''''''''*****

# Part 2
# Write a bash script that converts any TSV to a CSV and prints out the CSV. Give the command to run the file in a comment. Hint: Use an input variable!

for tsv_file in *.tsv; do
csv_file="${file%.tsv}.csv"
sed 's/\t/,/g' "tsv_file" > "csv_file"
cat "$csv_file"
done
#./lab5.sh file.tsv

# Part 3
# Given the following three strings, write a bash script that uses if statements to find which string is the biggest. Print out a meaningful statement that contains the string number (1, 2, or 3) and the string itself.
string1="This is a string"
string2="Hello"
string3="Strings are very cool"

if [[ ${#string1} -ge ${#string2} && ${#string1} -ge ${#string3} ]]; then
    echo "String 1 is the biggest: '$string1'"
elif [[ ${#string2} -ge ${#string1} && ${#string2} -ge ${#string3} ]]; then
    echo "String 2 is the biggest: '$string2'"
else
    echo "String 3 is the biggest: '$string3'"
fi

# Part 4 
# Write a bash script that uses a for loop to look at all the FASTA files in your current directory. Print out the file name and the headers in that file. Remember that FASTA headers start with >.

for file in *.fasta; do
    echo "File_Name: $file"
    grep '^>' "$file"
done

# Part 5
# Write a bash script that prints a given range of lines from a given file. For example, ./script.sh file.tsv 2 5 would print lines 2 to 5 from file.tsv. Give the command to run the file in a comment.

sed -n '2,5p' file.tsv
#./lab5.sh file.tsv 2 5